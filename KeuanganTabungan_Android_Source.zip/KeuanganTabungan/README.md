# Keuangan & Tabungan (Android)

Aplikasi Android offline untuk mencatat pemasukan dan pengeluaran pribadi maupun beberapa bisnis/tabungan. Setiap bisnis memiliki saldo sendiri; pilihan **Semua** menampilkan saldo gabungan.

## Fitur versi 1.0
- Saldo gabungan dan saldo per bisnis/tabungan.
- Pencatatan pemasukan dan pengeluaran dalam Rupiah.
- Riwayat transaksi dengan tanggal, bisnis, dan keterangan.
- Data tersimpan lokal otomatis menggunakan SQLite; tidak memerlukan internet.
- Menambah bisnis/tabungan sesuai kebutuhan.

## Build APK lewat HP menggunakan GitHub
1. Buat repository GitHub baru, misalnya `keuangan-tabungan`.
2. Ekstrak ZIP ini. Unggah **isi folder** (folder `app`, `build.gradle.kts`, `settings.gradle.kts`, `.github`, dan file lainnya) ke root repository, bukan ZIP-nya saja.
3. Buka tab **Actions**, pilih workflow **Build APK**, lalu tekan **Run workflow**. Jika baru pertama kali, izinkan Actions bila diminta.
4. Setelah selesai, buka hasil run dan unduh artifact **KeuanganTabungan-APK**.
5. Ekstrak artifact, lalu buka `app-debug.apk` di HP dan izinkan pemasangan dari sumber tersebut bila Android memintanya.

Catatan: APK belum disertakan dalam ZIP sumber ini; GitHub Actions yang membangunnya. Data aplikasi disimpan di perangkat. Hapus data/uninstall aplikasi dapat menghapus data lokal, jadi lakukan pencadangan perangkat sebelum reset atau uninstall.
