package id.app.keuangantabungan

import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FinanceDb(context: android.content.Context) : SQLiteOpenHelper(context, "keuangan_tabungan.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE businesses(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE)")
        db.execSQL("CREATE TABLE transactions(id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT NOT NULL, business_id INTEGER, title TEXT NOT NULL, amount INTEGER NOT NULL, note TEXT, date TEXT NOT NULL)")
        db.execSQL("INSERT INTO businesses(name) VALUES('Pribadi')")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun businesses(): List<Pair<Long,String>> {
        val out = mutableListOf<Pair<Long,String>>()
        readableDatabase.rawQuery("SELECT id,name FROM businesses ORDER BY id", null).use { c -> while(c.moveToNext()) out.add(c.getLong(0) to c.getString(1)) }
        return out
    }
    fun addBusiness(name: String) { val v=ContentValues().apply { put("name",name.trim()) }; writableDatabase.insertWithOnConflict("businesses",null,v,SQLiteDatabase.CONFLICT_IGNORE) }
    fun addTransaction(type:String, businessId:Long, title:String, amount:Long, note:String) {
        val v=ContentValues().apply { put("type",type); put("business_id",businessId); put("title",title); put("amount",amount); put("note",note); put("date",SimpleDateFormat("yyyy-MM-dd HH:mm",Locale("id","ID")).format(Date())) }
        writableDatabase.insert("transactions",null,v)
    }
    data class Tx(val id:Long,val type:String,val business:String,val title:String,val amount:Long,val note:String,val date:String)
    fun transactions(filter:Long?):List<Tx> {
        val sql="SELECT t.id,t.type,COALESCE(b.name,'Pribadi'),t.title,t.amount,COALESCE(t.note,''),t.date FROM transactions t LEFT JOIN businesses b ON b.id=t.business_id" + if(filter==null) "" else " WHERE t.business_id=?" + " ORDER BY t.id DESC"
        val args=if(filter==null) null else arrayOf(filter.toString())
        val out= mutableListOf<Tx>(); readableDatabase.rawQuery(sql,args).use { c -> while(c.moveToNext()) out.add(Tx(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getLong(4),c.getString(5),c.getString(6))) }; return out
    }
    fun totals(filter:Long?):Triple<Long,Long,Long> {
        val where=if(filter==null) "" else " WHERE business_id=?"; val args=if(filter==null) null else arrayOf(filter.toString())
        fun sum(type:String):Long { readableDatabase.rawQuery("SELECT COALESCE(SUM(amount),0) FROM transactions$where${if(where.isEmpty()) " WHERE" else " AND"} type=?", if(args==null) arrayOf(type) else arrayOf(args[0],type)).use { if(it.moveToFirst()) return it.getLong(0) }; return 0 }
        val income=sum("MASUK"); val expense=sum("KELUAR"); return Triple(income,expense,income-expense)
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); val db=FinanceDb(this); setContent { MaterialTheme { FinanceScreen(db) } } }
}

private fun rupiah(n:Long)=NumberFormat.getCurrencyInstance(Locale("id","ID")).format(n).replace(",00","")

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun FinanceScreen(db:FinanceDb) {
    var refresh by remember { mutableIntStateOf(0) }
    val businesses= remember(refresh) { db.businesses() }
    var selected by remember { mutableStateOf<Long?>(null) }
    var showAdd by remember { mutableStateOf(false) }; var showBusiness by remember { mutableStateOf(false) }
    var type by remember { mutableStateOf("MASUK") }; var title by remember { mutableStateOf("") }; var amount by remember { mutableStateOf("") }; var note by remember { mutableStateOf("") }; var newBusiness by remember { mutableStateOf("") }
    val totals= remember(refresh,selected) { db.totals(selected) }; val rows= remember(refresh,selected) { db.transactions(selected) }
    Scaffold(topBar={ TopAppBar(title={ Text("Keuangan & Tabungan",fontWeight=FontWeight.Bold) }, actions={ TextButton(onClick={showBusiness=true}) { Text("+ Bisnis") } }) }, floatingActionButton={ FloatingActionButton(onClick={showAdd=true}) { Text("+") } }) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad).padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
            item { Text("Pilih laporan", style=MaterialTheme.typography.titleMedium, fontWeight=FontWeight.Bold) }
            item { Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { FilterChip(selected=selected==null,onClick={selected=null},label={Text("Semua")}); businesses.forEach { (id,name)-> FilterChip(selected=selected==id,onClick={selected=id},label={Text(name)}) } } }
            item { Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.primaryContainer)) { Column(Modifier.padding(16.dp)) { Text("SALDO ${if(selected==null) "GABUNGAN" else businesses.firstOrNull{it.first==selected}?.second?.uppercase().orEmpty()}",style=MaterialTheme.typography.labelLarge); Text(rupiah(totals.third),style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold) } } }
            item { Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { SummaryCard("Pemasukan",totals.first,Modifier.weight(1f)); SummaryCard("Pengeluaran",totals.second,Modifier.weight(1f)) } }
            item { Text("Riwayat transaksi",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold) }
            if(rows.isEmpty()) item { Text("Belum ada transaksi. Tekan tombol + untuk mencatat pemasukan atau pengeluaran.",color=MaterialTheme.colorScheme.onSurfaceVariant) }
            items(rows) { tx -> Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) { Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) { Text(tx.title,fontWeight=FontWeight.SemiBold); Text((if(tx.type=="MASUK") "+ " else "− ")+rupiah(tx.amount),color=if(tx.type=="MASUK") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,fontWeight=FontWeight.Bold) }; Text("${tx.business} • ${tx.date}",style=MaterialTheme.typography.bodySmall); if(tx.note.isNotBlank()) Text(tx.note,style=MaterialTheme.typography.bodySmall) } } }
        }
    }
    if(showAdd) AlertDialog(onDismissRequest={showAdd=false},title={Text("Tambah transaksi")},text={ Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { FilterChip(selected=type=="MASUK",onClick={type="MASUK"},label={Text("Pemasukan")}); FilterChip(selected=type=="KELUAR",onClick={type="KELUAR"},label={Text("Pengeluaran")}) }
        var biz by remember { mutableStateOf(businesses.firstOrNull()?.first ?: 1L) }
        Text("Bisnis / tabungan"); businesses.forEach { (id,name)-> Row { RadioButton(selected=biz==id,onClick={biz=id}); Text(name,Modifier.padding(top=12.dp)) } }
        OutlinedTextField(title,{title=it},label={Text("Nama transaksi")},singleLine=true)
        OutlinedTextField(amount,{amount=it.filter(Char::isDigit)},label={Text("Jumlah (Rp)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),singleLine=true)
        OutlinedTextField(note,{note=it},label={Text("Keterangan (opsional)")})
    } },confirmButton={ TextButton(onClick={ val a=amount.toLongOrNull() ?: 0L; if(title.isNotBlank() && a>0) { db.addTransaction(type,biz,title.trim(),a,note.trim()); refresh++; title="";amount="";note="";showAdd=false } }) { Text("Simpan") } },dismissButton={TextButton(onClick={showAdd=false}) { Text("Batal") }})
    if(showBusiness) AlertDialog(onDismissRequest={showBusiness=false},title={Text("Tambah bisnis / tabungan")},text={OutlinedTextField(newBusiness,{newBusiness=it},label={Text("Nama bisnis atau tabungan")},singleLine=true)},confirmButton={TextButton(onClick={if(newBusiness.isNotBlank()){db.addBusiness(newBusiness);newBusiness="";refresh++;showBusiness=false}}){Text("Tambah")}},dismissButton={TextButton(onClick={showBusiness=false}){Text("Batal")}})
}

@Composable private fun SummaryCard(label:String,value:Long,modifier:Modifier=Modifier) { Card(modifier) { Column(Modifier.padding(12.dp)) { Text(label,style=MaterialTheme.typography.labelMedium); Text(rupiah(value),fontWeight=FontWeight.Bold) } } }
